"use strict";
/**
 * The service worker that keeps an app's own files on the visitor's device
 * (docs/app-files.md). The appFiles Vite plugin (appFiles.ts) writes it into
 * a build as `foss-earth-sw.js`, calling `install(self, files)` with the
 * build's file names, relative to the worker.
 *
 * Each of those names carries its file's content hash, so a kept copy is
 * never out of date: it is answered from the device without asking the
 * network, however long ago it was kept. The page itself is never kept: it
 * comes from the network every time, asked for while the worker starts, so
 * a new version shows on the next visit, and its new file names are
 * downloaded once. Every other request passes by: scene images are kept by
 * the scene loader, under their revisions.
 */
function install(worker, files) {
  const paths = new Set(files.map(name => new URL(name, worker.location.href).pathname));
  // One store for the worker's own address: a build's files, whichever of its pages asked for them.
  const cacheName = `foss-earth-app-files ${new URL(worker.location.href).pathname}`;
  const matchOptions = { ignoreVary: true, ignoreSearch: true };
  // Set when the page turns keeping off: until the page closes, this worker still sees its requests, and passes them by.
  let forgotten = false;

  /** A response worth keeping: the file itself, from this site. */
  const keepable = response => Boolean(response) && response.ok && response.status === 200 && response.type === "basic" && !response.redirected;

  /** The path of a URL this build lists, or null. */
  const listed = href => {
    let url;
    try { url = new URL(href, worker.location.href); } catch { return null; }
    return url.origin === worker.location.origin && paths.has(url.pathname) ? url.pathname : null;
  };

  async function answer(event, request, path) {
    const cache = await worker.caches.open(cacheName);
    const kept = await cache.match(path, matchOptions);
    if (kept) return kept;
    const response = await worker.fetch(request);
    if (keepable(response)) event.waitUntil(cache.put(path, response.clone()).catch(() => {}));
    return response;
  }

  worker.addEventListener("install", event => {
    // Nothing is fetched ahead: files are kept as the app asks for them. The new list takes over at once.
    event.waitUntil(worker.skipWaiting());
  });

  worker.addEventListener("activate", event => {
    event.waitUntil((async () => {
      // The page is asked for while the worker starts, not after.
      await worker.registration.navigationPreload?.enable().catch(() => {});
      const cache = await worker.caches.open(cacheName);
      // A file this version does not list belongs to an older one: its name will not be asked for again.
      for (const request of await cache.keys()) {
        if (!paths.has(new URL(request.url).pathname)) await cache.delete(request);
      }
      await worker.clients.claim();
    })());
  });

  worker.addEventListener("fetch", event => {
    const request = event.request;
    if (request.method !== "GET") return;
    if (request.mode === "navigate") {
      event.respondWith((async () => {
        // The request made while the worker started, if the browser made one; a failed one is asked again, as a page without this worker would be.
        const preloaded = await Promise.resolve(event.preloadResponse).catch(() => undefined);
        return preloaded || worker.fetch(request);
      })());
      return;
    }
    const path = forgotten ? null : listed(request.url);
    if (path) event.respondWith(answer(event, request, path));
  });

  // The page names what it loaded before this worker controlled it; those files are kept from the browser's cache.
  worker.addEventListener("message", event => {
    const data = event.data;
    if (data?.type === "foss-earth-forget") forgotten = true;
    if (data?.type !== "foss-earth-keep" || !Array.isArray(data.urls)) return;
    forgotten = false;
    event.waitUntil((async () => {
      const cache = await worker.caches.open(cacheName);
      for (const href of data.urls) {
        const path = typeof href === "string" ? listed(href) : null;
        if (!path || await cache.match(path, matchOptions)) continue;
        const response = await worker.fetch(path, { cache: "force-cache" }).catch(() => null);
        if (keepable(response)) await cache.put(path, response).catch(() => {});
      }
    })());
  });
}

install(self, ["assets/abstractAudioNode-DW4VTajR.js","assets/abstractSoundSource-DPuUWwWE.js","assets/animation-CISTNmG2.js","assets/atlasImagery.worker-DBCeQ3je.js","assets/babylon-shaders-glsl-BDB5h_-g.js","assets/babylon-shaders-wgsl-4lt-j9l0.js","assets/buffer-UQglctLJ.js","assets/cubemapToSphericalPolynomial-DRgu5DEn.js","assets/dataBuffer-C-wqV4qF.js","assets/dds-ClaI0Kyx.js","assets/decorators-CN1Ng5e5.js","assets/devTools-DmD3AOL3.js","assets/dumpTools-RRPsoo3c.js","assets/effectRenderer-BUMclq0v.js","assets/egm2008-15-nvvz7MYe.bin","assets/egm2008-30-BpPXoGjA.bin","assets/egm2008-60-bDxgbz8U.bin","assets/engineStore-CKkyXB7S.js","assets/floatingOriginMatrixOverrides-DqSG47nr.js","assets/flowGraphAsyncExecutionBlock-Bvl308Y3.js","assets/flowGraphBlock-ERqv2EAF.js","assets/flowGraphCachedOperationBlock-B_GY8dWh.js","assets/flowGraphExecutionBlock-Dlmpalig.js","assets/flowGraphExecutionBlockWithOutSignal-BCvgF3Qh.js","assets/guid-BXdVC_j_.js","assets/index-CvIJiYzu.css","assets/index-LkHTWnnH.js","assets/lightConstants-DUaNSuF5.js","assets/logger-CuBYPcDK.js","assets/math.axis-B0uJO_Mu.js","assets/math.color-Q4dgtYWM.js","assets/math.frustum-CcMj5eGx.js","assets/math.path-DGvzraWE.js","assets/math.plane-BUns5kps.js","assets/math.scalar.functions-CQA38JRp.js","assets/math.size-BvsHYnOu.js","assets/math.vector-lDpFf2si.js","assets/node-9ZucUUwN.js","assets/observable-CJ4J1f_C.js","assets/pickingInfo-DGMxPzFJ.js","assets/pointerEvents-_20Qj9Uk.js","assets/precisionDate-CfCevjl-.js","assets/scene-CzrUaDk5.js","assets/spatialWebAudioUpdaterComponent-DlOLam-_.js","assets/starCatalogue-DSWPyUwb.js","assets/subMesh-DqHJAKnZ.js","assets/texture-BbkUzidn.js","assets/textureTools-BJFM9JI2.js","assets/thinEngine-bHOD-y2H.js","assets/tools-B2YksR7s.js","assets/tools.functions-CpAPkLao.js","assets/typeStore-Cu_sj2zM.js","assets/viewer-B_xZxqD2.js","assets/webAudioBaseSubGraph-DhZYilV5.js","assets/webRequest-dqz0dHXK.js"]);
